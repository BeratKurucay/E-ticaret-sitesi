<?php
include("db.php");
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

if (isset($_GET['id'])) {
    try {
        $sorgu = $baglanti->prepare("DELETE FROM [Ürün] WHERE ÜrünID = ?");
        $sorgu->execute([$_GET['id']]);
        echo "Silme başarılı.";
    } catch (PDOException $e) {
        echo "Silme Hatası: " . $e->getMessage();
        exit;
    }
}

header("Location: panel.php");
exit;
