<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

include("db.php");

// Sayılar
$urunSayisi = $baglanti->query("SELECT COUNT(*) FROM Ürün")->fetchColumn();
$siparisSayisi = $baglanti->query("SELECT COUNT(*) FROM Sipariş")->fetchColumn();
$kullaniciSayisi = $baglanti->query("SELECT COUNT(*) FROM Müşteri")->fetchColumn();

// Son ürünler
$urunler = $baglanti->query("SELECT * FROM Ürün ORDER BY ÜrünID DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>Yönetici Paneli</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
  <h1 class="mb-4">Hoş Geldiniz, <?= $_SESSION["admin_kadi"] ?? 'Admin' ?></h1>

  <div class="row g-3">
    <div class="col-md-4">
      <div class="card text-bg-primary">
        <div class="card-body">
          <h5 class="card-title">Toplam Ürün</h5>
          <p class="card-text fs-3"><?= $urunSayisi ?></p>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card text-bg-success">
        <div class="card-body">
          <h5 class="card-title">Toplam Sipariş</h5>
          <p class="card-text fs-3"><?= $siparisSayisi ?></p>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card text-bg-warning">
        <div class="card-body">
          <h5 class="card-title">Toplam Kullanıcı</h5>
          <p class="card-text fs-3"><?= $kullaniciSayisi ?></p>
        </div>
      </div>
    </div>
  </div>

  <h3 class="mt-5">Tum Ürünler</h3>
  <table class="table table-bordered mt-2">
    <thead>
      <tr>
        <th>Ürün Adı</th>
        <th>Fiyat</th>
        <th>Sil</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($urunler as $urun): ?>
        <tr>
          <td><?= htmlspecialchars($urun['Ad']) ?></td>
          <td><?= number_format($urun['Fiyat'], 2) ?> TL</td>
          <td><a href="urun-sil.php?id=<?= $urun['ÜrünID'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Ürünü silmek istediğinizden emin misiniz?')">Sil</a></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <div class="mt-4">
    <a href="urun-ekle.php" class="btn btn-outline-primary">Ürün Ekle</a>
    <a href="siparisler.php" class="btn btn-outline-success">Siparişler</a>
    <a href="parola-degistir.php" class="btn btn-outline-warning">Parola Değiştir</a>
    <a href="cikis.php" class="btn btn-outline-danger">Çıkış Yap</a>
  </div>
</div>
</body>
</html>
