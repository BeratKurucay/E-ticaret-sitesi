<?php
include("db.php");
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $kadi = $_POST["KullanıcıAdı"];
    $sifre = $_POST["Şifre"];

    $sorgu = $baglanti->prepare("SELECT * FROM dbo.Yönetici WHERE KullanıcıAdı = ? AND Şifre = ?");
    $sorgu->execute([$kadi, $sifre]);
    $kullanici = $sorgu->fetch(PDO::FETCH_ASSOC);

    if ($kullanici) {
        $_SESSION["admin_id"] = $kullanici["YöneticiID"];
        $_SESSION["admin_kadi"] = $kullanici["KullanıcıAdı"];
        header("Location: panel.php");
        exit;
    } else {
        $hata = "Kullanıcı adı veya şifre yanlış!";
    }
}
?>
<form method="post">
  <input name="KullanıcıAdı" placeholder="Kullanıcı Adı">
  <input name="Şifre" type="password" placeholder="Şifre">
  <button>Giriş Yap</button>
</form>
