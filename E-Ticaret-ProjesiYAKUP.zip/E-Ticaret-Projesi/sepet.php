<?php
session_start();
include("db.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $musteriID = $_SESSION['MüşteriID'] ?? null;

    if (!$musteriID) {
        echo "Giriş yapılmamış.";
        exit;
    }

    $adres1 = $_POST['AdresSatırı1'] ?? '';
    $adres2 = $_POST['AdresSatırı2'] ?? '';
    $il = $_POST['İl'] ?? '';
    $ilce = $_POST['İlçe'] ?? '';
    $posta = $_POST['PostaKodu'] ?? '';
    $acikadres = $_POST['AçıkAdres'] ?? '';

    $adresSorgu = $baglanti->prepare("INSERT INTO Adres (MüşteriID, AdresSatırı1, AdresSatırı2, İl, İlçe, PostaKodu, AçıkAdres) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $adresSorgu->execute([$musteriID, $adres1, $adres2, $il, $ilce, $posta, $acikadres]);

    // En son eklenen adresi sakla
    $_SESSION['adresID'] = $baglanti->lastInsertId();

    echo "<p style='color:green;'>Adres kaydedildi. Şimdi ödeme yapabilirsiniz.</p>";
}
?>


<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Alışveriş Sepetiniz</title>
    <link rel="stylesheet" href="sepet.css">
</head>
<body >

<h1>Alışveriş Sepetiniz</h1>
<div class="sepet">
    <form method="post" class="urun-listesi">
        <?php
        $toplam = 0;
        if (!empty($_SESSION['sepet'])):
            foreach ($_SESSION['sepet'] as $id => $urun):
                $urun_toplam = $urun['fiyat'] * $urun['adet'];
                $toplam += $urun_toplam;
        ?>
        <div class="urun">
            <img src="<?= $urun['resim'] ?>" alt="">
            <div style="flex-grow:1">
                <div class="urun-ad"><?= $urun['ad'] ?></div>
                <div><?= number_format($urun['fiyat'], 2) ?> TL</div>
            </div>
            <input type="number" name="adet[<?= $id ?>]" value="<?= $urun['adet'] ?>" class="adet-input" min="1">
            <div style="margin-left: 20px;"><?= number_format($urun_toplam, 2) ?> TL</div>
            <a href="?sil=<?= $id ?>" class="btn-sil">🗑</a>
        </div>
        <?php
            endforeach;
        else:
        ?>
        <p style="text-align:center;">Sepetinizde ürün bulunmamaktadır.</p>
        <?php endif; ?>
        <div class="alt-bar">
            <a href="index.php">← Alışverişe Devam Et</a>
              <a href="?temizle=1" class="btn-temizle">❌ Sepeti Temizle</a>
            <button type="submit" name="guncelle" class="btn btn-guncelle">🔄 Sepeti Güncelle</button>
        </div>
    </form>

    <div class="ozet">
        <h3>Sipariş Özeti</h3>
        <p>Ara Toplam: <?= number_format($toplam, 2) ?> TL</p>
        <p>Kargo: Hesaplanacak</p>
        <hr>
        <p><strong>Genel Toplam:</strong> <?= number_format($toplam, 2) ?> TL</p>
        <br>
       <div class="adres-formu">
  <form method="post" action="odeme.php" class="odeme-form">
  <h4>Adres Bilgileri</h4>
  <label>Adres Satırı 1</label>
  <input type="text" name="AdresSatırı1" required>
  
  <label>Adres Satırı 2</label>
  <input type="text" name="AdresSatırı2">

  <label>İl</label>
  <input type="text" name="İl" required>

  <label>İlçe</label>
  <input type="text" name="İlçe" required>

  <label>Posta Kodu</label>
  <input type="text" name="PostaKodu" required>

  <label>Açık Adres</label>
  <textarea name="AçıkAdres" rows="3" required></textarea>

  <button type="submit" class="btn btn-odeme">✔️ Ödemeyi Tamamla</button>
</form>






</body>
</html>
