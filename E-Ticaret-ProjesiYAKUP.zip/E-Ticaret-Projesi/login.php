<?php
session_start();
include("db.php");

$hata = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $sifre = $_POST['sifre'] ?? '';

    try {
        // Email ve şifre ile müşteri bilgilerini çek
        $sorgu = $baglanti->prepare("SELECT * FROM [Müşteri] WHERE [Eposta] = ? AND [Şifre] = ?");
        $sorgu->execute([$email, $sifre]);
        $kullanici = $sorgu->fetch(PDO::FETCH_ASSOC);

        if ($kullanici) {
            // Oturuma müşteri bilgilerini ata
            $_SESSION['MüşteriID'] = $kullanici['MüşteriID'];
            $_SESSION['email'] = $kullanici['Eposta'];

            // Ödeme sayfasına yönlendir
            header("Location: odeme.php");
            exit;
        } else {
            $hata = "❌ E-posta veya şifre hatalı.";
        }
    } catch (PDOException $e) {
        $hata = "Veritabanı hatası: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Müşteri Girişi</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }

        .container {
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            width: 350px;
            text-align: center;
        }

        h2 {
            color: #333;
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #555;
            font-weight: bold;
            text-align: left;
        }

        input[type=email], input[type=password] {
            width: calc(100% - 22px);
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
            font-size: 16px;
        }

        button {
            background-color: #007bff;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
            font-size: 18px;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #0056b3;
        }

        .error {
            color: #dc3545;
            margin-top: 10px;
        }

        p {
            margin-top: 20px;
            color: #777;
        }

        p a {
            color: #007bff;
            text-decoration: none;
        }

        p a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Müşteri Girişi</h2>

    <form method="post">
        <label for="email">E-Posta:</label>
        <input type="email" name="email" required>

        <label for="sifre">Şifre:</label>
        <input type="password" name="sifre" required>

        <button type="submit">Giriş Yap</button>
    </form>

    <?php if ($hata): ?>
        <p class="error"><?= htmlspecialchars($hata) ?></p>
    <?php endif; ?>

    <p>Hesabınız yok mu? <a href="register.php">Kayıt Ol</a></p>
</div>

</body>
</html>