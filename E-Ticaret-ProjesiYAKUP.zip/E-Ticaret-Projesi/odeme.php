<?php
session_start();
include("db.php");

if (!$baglanti) die("Veritabanı bağlantı hatası.");

if (empty($_SESSION['sepet'])) {
    header("Location: index.php");
    exit;
}

$mesaj = "";
$toplam = 0;
foreach ($_SESSION['sepet'] as $urun) {
    $toplam += $urun['fiyat'] * $urun['adet'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $musteriID = $_SESSION['MüşteriID'] ?? null;

    if (!$musteriID) {
        $mesaj = "<p style='color:red;'>Müşteri oturumu yok.</p>";
    } else {
        // Adres bilgileri
        $adres1 = $_POST['AdresSatırı1'] ?? 'Belirtilmedi';
        $adres2 = $_POST['AdresSatırı2'] ?? '-';
        $il = $_POST['İl'] ?? 'Belirtilmedi';
        $ilce = $_POST['İlçe'] ?? 'Belirtilmedi';
        $posta = $_POST['PostaKodu'] ?? '00000';
        $acikAdres = $_POST['AçıkAdres'] ?? 'Belirtilmedi';

        // Ödeme bilgileri
        $kart = $_POST['kart'] ?? '';
        $son = $_POST['sonkullanma'] ?? '';
        $cvv = $_POST['cvv'] ?? '';
        $odemeYontemi = $_POST['yontem'] ?? 'Kredi Kartı';

        try {
            // 1. Adres ekleme
            $stmtAdres = $baglanti->prepare("INSERT INTO [Adres] 
                ([MüşteriID], [AdresSatırı1], [AdresSatırı2], [İl], [İlçe], [PostaKodu], [AçıkAdres]) 
                VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmtAdres->execute([$musteriID, $adres1, $adres2, $il, $ilce, $posta, $acikAdres]);

            // SQL Server'da lastInsertId() genellikle çalışmaz; bu nedenle en son adresi bu şekilde çekiyoruz:
            $adresID = $baglanti->query("SELECT TOP 1 AdresID FROM [Adres] WHERE MüşteriID = $musteriID ORDER BY AdresID DESC")->fetchColumn();

            // 2. ÖdemeBilgisi ekleme
            $stmtOdeme = $baglanti->prepare("INSERT INTO [ÖdemeBilgisi] 
                ([MüşteriID], [KartNumarası], [SonKullanmaTarihi], [CVV], [ÖdemeYöntemi])
                VALUES (?, ?, ?, ?, ?)");
            $stmtOdeme->execute([$musteriID, $kart, $son, $cvv, $odemeYontemi]);

            // 3. Sipariş ekleme
            $tarih = date('Y-m-d H:i:s');
            $stmtSiparis = $baglanti->prepare("INSERT INTO [Sipariş] 
                ([MüşteriID], [SiparişTarihi], [ToplamTutar], [TeslimatAdresID], [FaturaAdresID], [ÖdemeYöntemi], [SiparişDurumu]) 
                VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmtSiparis->execute([$musteriID, $tarih, $toplam, $adresID, $adresID, $odemeYontemi, 'Hazırlanıyor']);

            // Sepeti temizle
            unset($_SESSION['sepet']);

            $mesaj = "<p style='color:green;'>✔️ Sipariş başarıyla tamamlandı.</p>";

        } catch (PDOException $e) {
            $mesaj = "<p style='color:red;'>Hata: " . $e->getMessage() . "</p>";
        }
    }
}
?>


<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Ödeme</title>
    <link rel="stylesheet" href="sepet.css">
    <style>
        .odeme-form input {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 16px;
        }
        .odeme-form {
            max-width: 400px;
            margin: auto;
        }
    </style>
</head>
<body>
<center>
<h1>💳 Ödeme Sayfası</h1>
<div class="ozet">
    <h3>Genel Toplam: <?= number_format($toplam, 2) ?> TL</h3>
    <p>Kargo: Ücretsiz</p>
    <hr>
    <?= $mesaj ?>
    <form method="post" class="odeme-form">
        <label>Kart Numarası:</label>
        <input type="text" name="kart" placeholder="XXXX XXXX XXXX XXXX" required>
        <label>Son Kullanma Tarihi:</label>
        <input type="text" name="sonkullanma" placeholder="AA/YY" required>
        <label>Ad Soyad:</label> <input type="text" name="adsoyad" placeholder="Kart üzerindeki ad soyad" required>
        <label>CVV:</label>
        <input type="text" name="cvv" placeholder="3 haneli güvenlik kodu" required>
        <button type="submit" class="btn btn-odeme">✔️ Ödemeyi Tamamla</button>
    </form>
</div>
</center>
</body>
</html>
