<?php
$host = 'elaro.database.windows.net';
$dbname = 'elaro';
$username = 'elaroadmin';
$password = 'M3sl3ki.proje';

try {
    $baglanti = new PDO("sqlsrv:Server=$host;Database=$dbname", $username, $password);
    $baglanti->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Bağlantı hatası: " . $e->getMessage());
}

// Pantolon kategorisi için kategori ID (örnek olarak 7 verilmiştir)
$kategori_id = 11;

// Kategori adı
$katSorgu = $baglanti->prepare("SELECT Ad FROM dbo.kategori WHERE KategoriID = ?");
$katSorgu->execute([$kategori_id]);
$kat = $katSorgu->fetch(PDO::FETCH_ASSOC);

// Ürünleri çek
$urunSorgu = $baglanti->prepare("SELECT * FROM dbo.Ürün WHERE KategoriID = ?");
$urunSorgu->execute([$kategori_id]);
$urunler = $urunSorgu->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>PikPazar | Pantolon</title>
  <link rel="stylesheet" href="E-Ticaret.css">
</head>
<body>

<?php include("partials/header.php"); ?>
<?php include("partials/menu.php"); ?>

<section class="urunler-bolumu">
  <h2><?= $kat ? $kat['Ad'] : 'Kategori Bulunamadı' ?></h2>
  <div class="urunler-grid">
    <?php foreach ($urunler as $urun): ?>
      <div class="urun-karti">
        <img src="<?= $urun['GörselURL'] ?>" alt="<?= $urun['Ad'] ?>">
        <h4><?= $urun['Ad'] ?></h4>
        <p style="color:crimson; font-weight:bold;"><?= $urun['Fiyat'] ?> TL</p>

        <a href="urun-detay.php?id=<?= $urun['ÜrünID'] ?>" class="btn-incele">Ürünü İncele</a>

        <button class="sepete-ekle" 
                data-isim="<?= $urun['Ad'] ?>" 
                data-fiyat="<?= $urun['Fiyat'] ?>" 
                data-resim="<?= $urun['GörselURL'] ?>">
          Sepete Ekle
        </button>
      </div>
    <?php endforeach; ?>
  </div>
</section>

<?php include("partials/footer.php"); ?>
<script src="sepet.js"></script>
</body>
</html>