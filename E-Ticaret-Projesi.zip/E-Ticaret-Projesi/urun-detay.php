<?php
$host = 'elaro.database.windows.net';
$dbname = 'elaro';
$username = 'elaroadmin';
$password = 'M3sl3ki.proje';

try {
    $baglanti = new PDO("sqlsrv:Server=$host;Database=$dbname", $username, $password);
    $baglanti->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Bağlantı hatası: " . $e->getMessage());
}

$urun_id = $_GET['id'] ?? null;
$urun = null;

if ($urun_id) {
    $sorgu = $baglanti->prepare("SELECT * FROM dbo.Ürün WHERE ÜrünID = ?");
    $sorgu->execute([$urun_id]);
    $urun = $sorgu->fetch(PDO::FETCH_ASSOC);
}

if (!$urun) {
    echo "<div style='padding:40px; text-align:center; font-size:18px;'>Ürün bulunamadı.</div>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($urun['Ad']) ?> | PikPazar</title>
    <link rel="stylesheet" href="E-Ticaret.css">
    <style>
        .btn-sepete-ekle {
            display: inline-block;
            width: 80%;
            background-color: #ffd700;
            color: #000;
            border: none;
            padding: 12px;
            margin: 10px auto;
            font-weight: bold;
            text-align: center;
            border-radius: 25px;
            cursor: pointer;
            text-decoration: none;
            transition: 0.3s;
        }
        .btn-sepete-ekle:hover {
            background-color: #e6be00;
        }
        .urun-detay {
            text-align: center;
            max-width: 600px;
            margin: auto;
            padding: 30px;
        }
        .urun-detay img {
            max-width: 300px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

<?php include("partials/header.php"); ?>
<?php include("partials/menu.php"); ?>

<div class="urun-detay">
    <img src="<?= htmlspecialchars($urun['GörselURL']) ?>" alt="<?= htmlspecialchars($urun['Ad']) ?>">
    
    <h2><?= htmlspecialchars($urun['Ad']) ?></h2>
    <p style="margin-top:10px; font-size:17px;"><?= htmlspecialchars($urun['Açıklama']) ?></p>
    <p class="fiyat" style="font-size:20px; color:#d10d0d; margin-top:15px; font-weight:bold;"><?= htmlspecialchars($urun['Fiyat']) ?> TL</p>

    <div class="secenekler">
  <label for="beden">Beden:</label>
  <select id="beden" name="beden">
    <option value="S">S</option>
    <option value="M">M</option>
    <option value="L">L</option>
    <option value="XL">XL</option>
  </select>

  <label for="renk">Renk:</label>
  <select id="renk" name="renk">
    <option value="Beyaz">Beyaz</option>
    <option value="Mavi">Mavi</option>
    <option value="Siyah">Siyah</option>
  </select>
</div>

<div class="yorumlar">
  <h3>Müşteri Yorumları (Ortalama Yıldız: 4.5)</h3>
  <div class="yorum">
    <p><strong>Ahmet:</strong> Çok kaliteli. (5 Yıldız)</p>
  </div>
  <div class="yorum">
    <p><strong>Ayşe:</strong> Biraz dar kesim. (4 Yıldız)</p>
  </div>
</div>

    <a href="sepet.php" 
       class="btn-sepete-ekle sepete-ekle"
       data-isim="<?= htmlspecialchars($urun['Ad']) ?>"
       data-fiyat="<?= htmlspecialchars($urun['Fiyat']) ?>"
       data-resim="<?= htmlspecialchars($urun['GörselURL']) ?>">
        HEMEN AL
    </a>

    <button class="btn-sepete-ekle sepete-ekle"
       data-isim="<?= htmlspecialchars($urun['Ad']) ?>"
       data-fiyat="<?= htmlspecialchars($urun['Fiyat']) ?>"
       data-resim="<?= htmlspecialchars($urun['GörselURL']) ?>">
        Sepete Ekle
    </button>
</div>

<?php include("partials/footer.php"); ?>
<script src="sepet.js"></script>
</body>
</html>
