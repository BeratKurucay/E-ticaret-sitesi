<?php
session_start();
require_once '../db.php'; // Veritabanı bağlantısı

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $ad = $_POST["ad"];
    $aciklama = $_POST["aciklama"];
    $fiyat = $_POST["fiyat"];
    $stok = $_POST["stok"];
    $kategori = $_POST["kategori"];
    $marka = $_POST["marka"];
    $renk = $_POST["renk"];
    $gorsel = $_POST["gorsel"];

    $sql = "INSERT INTO Urun (Ad, Aciklama, Fiyat, StokAdedi, KategoriID, Marka, Renk, GorselURL)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$ad, $aciklama, $fiyat, $stok, $kategori, $marka, $renk, $gorsel]);

    echo "<p style='color:green;'>Ürün başarıyla eklendi.</p>";
}
?>

<h2>Yeni Ürün Ekle</h2>
<form method="post">
    <input name="ad" placeholder="Ürün Adı" required><br><br>
    <textarea name="aciklama" placeholder="Açıklama" required></textarea><br><br>
    <input name="fiyat" type="number" step="0.01" placeholder="Fiyat" required><br><br>
    <input name="stok" type="number" placeholder="Stok Adedi" required><br><br>
    <input name="kategori" type="number" placeholder="KategoriID" required><br><br>
    <input name="marka" placeholder="Marka"><br><br>
    <input name="renk" placeholder="Renk"><br><br>
    <input name="gorsel" placeholder="Görsel URL"><br><br>
    <button type="submit">Ürünü Ekle</button>
</form>
