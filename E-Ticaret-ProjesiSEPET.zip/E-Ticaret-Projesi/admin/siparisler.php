<?php
// admin/siparisler.php
session_start();
require_once '../db.php';

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

$tarihBasla = $_GET['basla'] ?? null;
$tarihBitir = $_GET['bitir'] ?? null;

if ($tarihBasla && $tarihBitir) {
    $stmt = $pdo->prepare("SELECT S.SiparisID, S.Tarih, S.ToplamTutar, S.Durum, M.Ad AS MusteriAd, M.Soyad AS MusteriSoyad
                            FROM Siparis S
                            JOIN Musteri M ON S.MusteriID = M.MusteriID
                            WHERE S.Tarih BETWEEN ? AND ?
                            ORDER BY S.Tarih DESC");
    $stmt->execute([$tarihBasla, $tarihBitir]);
} else {
    $stmt = $pdo->query("SELECT S.SiparisID, S.Tarih, S.ToplamTutar, S.Durum, M.Ad AS MusteriAd, M.Soyad AS MusteriSoyad
                          FROM Siparis S
                          JOIN Musteri M ON S.MusteriID = M.MusteriID
                          ORDER BY S.Tarih DESC");
}
$siparisler = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Sipariş Listesi</title>
</head>
<body>
<h2>Tüm Siparişler</h2>
<form method="get">
    Tarih Aralığı:
    <input type="date" name="basla" value="<?= htmlspecialchars($tarihBasla) ?>">
    -
    <input type="date" name="bitir" value="<?= htmlspecialchars($tarihBitir) ?>">
    <button type="submit">Filtrele</button>
</form>
<br>
<table border="1" cellpadding="10">
    <tr>
        <th>Sipariş ID</th>
        <th>Müşteri</th>
        <th>Tarih</th>
        <th>Toplam Tutar</th>
        <th>Durum</th>
        <th>Detay</th>
        <th>Durumu Değiştir</th>
    </tr>
    <?php foreach ($siparisler as $siparis): ?>
        <tr>
            <td><?= $siparis['SiparisID'] ?></td>
            <td><?= htmlspecialchars($siparis['MusteriAd'] . ' ' . $siparis['MusteriSoyad']) ?></td>
            <td><?= $siparis['Tarih'] ?></td>
            <td><?= $siparis['ToplamTutar'] ?> ₺</td>
            <td><?= $siparis['Durum'] ?></td>
            <td><a href="siparis-detay.php?id=<?= $siparis['SiparisID'] ?>">Görüntüle</a></td>
            <td>
                <form method="post" action="siparis-durum.php" style="display:inline;">
                    <input type="hidden" name="id" value="<?= $siparis['SiparisID'] ?>">
                    <select name="durum">
                        <option<?= $siparis['Durum'] == 'Hazırlanıyor' ? ' selected' : '' ?>>Hazırlanıyor</option>
                        <option<?= $siparis['Durum'] == 'Kargoda' ? ' selected' : '' ?>>Kargoda</option>
                        <option<?= $siparis['Durum'] == 'Teslim Edildi' ? ' selected' : '' ?>>Teslim Edildi</option>
                    </select>
                    <button type="submit">Kaydet</button>
                </form>
            </td>
        </tr>
    <?php endforeach; ?>
</table>
</body>
</html>
