<?php
session_start();
if ($_POST) {
    $kullanici = $_POST['kullanici'];
    $sifre = $_POST['sifre'];

    if ($kullanici === "admin" && $sifre === "1234") {
        $_SESSION['admin'] = true;
        header("Location: panel.php");
        exit;
    } else {
        echo "Hatalı giriş.";
    }
}
?>
<form method="post">
  <input name="kullanici" placeholder="Kullanıcı Adı">
  <input name="sifre" type="password" placeholder="Şifre">
  <button>Giriş Yap</button>
</form>
