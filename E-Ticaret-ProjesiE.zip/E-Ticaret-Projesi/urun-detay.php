<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Ürün Detayı</title>
    <link rel="stylesheet" href="E-Ticaret.css">
</head>
<body>

<?php include("partials/header.php"); ?>  
<?php include("partials/menu.php"); ?>

<section class="sepet-alani" id="orta-sepet" style="display:none;">
    <h2>Sepetiniz</h2>
    <ul id="sepet-listesi"></ul>
    <button id="odeme-yap" style="display:none;">Ödemeyi Tamamla</button>
</section>

<div class="urun-detay">
    <?php
    $urun_id = $_GET['id'];
    $urun = [
        'ad' => 'Düz Renk Klasik Gömlek',
        'fiyat' => 279,
        'resim' => [
            'https://i.hizliresim.com/rm92gmo.png',
            'https://i.hizliresim.com/cedu2y1.png',
            'https://i.hizliresim.com/ptld0e0.png'
        ],
        'aciklama' => 'Bu şık gömlek, gardırobunuzun vazgeçilmezi olacak.',
        'bedenler' => ['S', 'M', 'L', 'XL'],
        'renkler' => ['Beyaz', 'Mavi', 'Siyah'],
        'ortalama_yildiz' => 4.5,
        'yorumlar' => [
            ['kullanici' => 'Ahmet', 'yorum' => 'Çok kaliteli.', 'yildiz' => 5],
            ['kullanici' => 'Ayşe', 'yorum' => 'Biraz dar kesim.', 'yildiz' => 4]
        ]
    ];
    ?>

    <div class="urun-slider-container zoom-container">
        <?php foreach ($urun['resim'] as $index => $resim): ?>
            <img src="<?php echo htmlspecialchars($resim); ?>" class="<?php echo $index === 0 ? 'active' : ''; ?>">
        <?php endforeach; ?>
        <div class="zoom-lens"></div>
        <button class="urun-slider-btn left">&#9664;</button>
        <button class="urun-slider-btn right">&#9654;</button>
    </div>

    <h2><?php echo htmlspecialchars($urun['ad']); ?></h2>
    <p><?php echo htmlspecialchars($urun['aciklama']); ?></p>
    <p class="fiyat"><?php echo htmlspecialchars($urun['fiyat']); ?> TL</p>

    <div class="secenekler">
        <div>
            <label for="beden">Beden:</label>
            <select id="beden" name="beden">
                <?php foreach ($urun['bedenler'] as $beden): ?>
                    <option value="<?php echo htmlspecialchars($beden); ?>"><?php echo htmlspecialchars($beden); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div>
            <label for="renk">Renk:</label>
            <select id="renk" name="renk">
                <?php foreach ($urun['renkler'] as $renk): ?>
                    <option value="<?php echo htmlspecialchars($renk); ?>"><?php echo htmlspecialchars($renk); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
    </div>

    <div class="yorumlar">
        <h3>Müşteri Yorumları (Ortalama Yıldız: <?php echo htmlspecialchars($urun['ortalama_yildiz']); ?>)</h3>
        <?php foreach ($urun['yorumlar'] as $yorum): ?>
            <div class="yorum">
                <p><strong><?php echo htmlspecialchars($yorum['kullanici']); ?>:</strong>
                <?php echo htmlspecialchars($yorum['yorum']); ?> (<?php echo htmlspecialchars($yorum['yildiz']); ?> Yıldız)</p>
            </div>
        <?php endforeach; ?>
    </div>

    <button class="sepete-ekle" 
        data-isim="<?php echo htmlspecialchars($urun['ad']); ?>" 
        data-fiyat="<?php echo htmlspecialchars($urun['fiyat']); ?>" 
        data-resim="<?php echo htmlspecialchars($urun['resim'][0]); ?>">
        Sepete Ekle
    </button>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const images = document.querySelectorAll('.urun-slider-container img');
    const lens = document.querySelector('.zoom-lens');
    const leftBtn = document.querySelector('.urun-slider-btn.left');
    const rightBtn = document.querySelector('.urun-slider-btn.right');
    let currentIndex = 0;

    function showImage(index) {
        images.forEach((img, i) => img.classList.toggle('active', i === index));
        lens.style.backgroundImage = `url(${images[index].src})`;
    }

    leftBtn.addEventListener('click', function() {
        currentIndex = (currentIndex - 1 + images.length) % images.length;
        showImage(currentIndex);
    });

    rightBtn.addEventListener('click', function() {
        currentIndex = (currentIndex + 1) % images.length;
        showImage(currentIndex);
    });

    images.forEach(img => {
        img.addEventListener('mousemove', moveLens);
        img.addEventListener('mouseenter', () => lens.style.visibility = 'visible');
        img.addEventListener('mouseleave', () => lens.style.visibility = 'hidden');
    });

    function moveLens(e) {
        const img = images[currentIndex];
        const rect = img.getBoundingClientRect();
        const x = e.pageX - rect.left - window.pageXOffset;
        const y = e.pageY - rect.top - window.pageYOffset;
        let lensX = x - lens.offsetWidth / 2;
        let lensY = y - lens.offsetHeight / 2;

        lensX = Math.max(0, Math.min(lensX, img.width - lens.offsetWidth));
        lensY = Math.max(0, Math.min(lensY, img.height - lens.offsetHeight));

        lens.style.left = lensX + 'px';
        lens.style.top = lensY + 'px';
        lens.style.backgroundSize = `${img.width * 2}px ${img.height * 2}px`;
        lens.style.backgroundPosition = `-${lensX * 2}px -${lensY * 2}px`;
    }

    const sepeteEkleBtn = document.querySelector('.sepete-ekle');
    sepeteEkleBtn.addEventListener('click', function() {
        const isim = this.dataset.isim;
        const fiyat = this.dataset.fiyat;
        const resim = this.dataset.resim;

        const formData = new FormData();
        formData.append('ad', isim);
        formData.append('fiyat', fiyat);
        formData.append('resim', resim);

        fetch('sepetEkle.php', {
            method: 'POST',
            body: formData
        }).then(res => res.json()).then(data => {
            if (data.success) {
                alert(isim + ' sepete eklendi!');
                updateSepetListesi();
            }
        });
    });

    const sepetAcBtn = document.getElementById('sepet-ac');
    const ortaSepet = document.getElementById('orta-sepet');
    sepetAcBtn?.addEventListener('click', function() {
        ortaSepet.style.display = 'block';
        updateSepetListesi();
    });

    function updateSepetListesi() {
        fetch('sepet.php')
            .then(response => response.text())
            .then(html => {
                document.getElementById('sepet-listesi').innerHTML = html;
            });
    }
});
</script>

<?php include("partials/footer.php"); ?>

</body>
</html>
