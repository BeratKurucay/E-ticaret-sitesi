<?php
session_start();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Sepetim | PikPazar</title>
  <link rel="stylesheet" href="E-Ticaret.css">
</head>
<body>
<?php include("partials/header.php"); ?>
<?php include("partials/menu.php"); ?>

<section class="sepet-alani" style="margin: 50px auto; max-width: 1000px;">
  <h2 style="text-align:center;">Sepetiniz</h2>
  <ul id="sepet-listesi" style="display: flex; flex-wrap: wrap; gap: 20px; justify-content: center; padding: 0;"></ul>
  <div style="text-align: center; margin-top: 20px;">
    <button id="odeme-yap" style="padding: 12px 30px; font-size: 16px; background: #4CAF50; color: white; border: none; border-radius: 8px; cursor: pointer;">Ödemeyi Tamamla</button>
  </div>
</section>

<div id="musteri-popup" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.6); justify-content:center; align-items:center; z-index:9999;">
  <div style="background:white; padding:30px; border-radius:10px; text-align:center; max-width:500px; width:90%;">
    <h2>Müşteri Bilgileri</h2>
    <form id="musteri-formu">
      <input type="text" id="adsoyad" placeholder="İsim Soyisim" required style="margin:10px; padding:10px; width:90%;"><br>
      <input type="email" id="email" placeholder="E-Posta" required style="margin:10px; padding:10px; width:90%;"><br>
      <input type="tel" id="telefon" placeholder="Telefon (05XXXXXXXXX)" required style="margin:10px; padding:10px; width:90%;"><br>
      <textarea id="adres" placeholder="Teslimat Adresi" required style="margin:10px; padding:10px; width:90%; height:80px;"></textarea><br>
      <button type="submit" style="background:green; color:white; padding:10px 30px; margin-top:10px; border-radius:6px;">Devam Et</button>
    </form>
    <button id="musteri-kapat" style="margin-top:15px; background:red; color:white; padding:8px 20px; border-radius:5px;">Vazgeç</button>
  </div>
</div>

<div id="kart-popup" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.6); justify-content:center; align-items:center; z-index:9999;">
  <div style="background:white; padding:30px; border-radius:10px; text-align:center; max-width:500px; width:90%;">
    <h2>Kredi Kartı Bilgileri</h2>
    <form id="kart-formu">
      <input type="text" id="kart-ad" placeholder="Kart Üzerindeki İsim" required style="margin:10px; padding:10px; width:90%;"><br>
      <input type="text" id="kart-numara" placeholder="Kart Numarası (16 hane)" maxlength="16" required style="margin:10px; padding:10px; width:90%;"><br>
      <input type="text" id="kart-ay" placeholder="Ay (MM)" maxlength="2" required style="margin:10px; padding:10px; width:43%; display:inline-block;">
      <input type="text" id="kart-yil" placeholder="Yıl (YY)" maxlength="2" required style="margin:10px; padding:10px; width:43%; display:inline-block;"><br>
      <input type="text" id="kart-cvv" placeholder="CVV (3 hane)" maxlength="3" required style="margin:10px; padding:10px; width:90%;"><br>
      <button type="submit" style="background:green; color:white; padding:10px 30px; margin-top:10px; border-radius:6px;">Ödemeyi Tamamla</button>
    </form>
    <button id="kart-kapat" style="margin-top:15px; background:red; color:white; padding:8px 20px; border-radius:5px;">Vazgeç</button>
  </div>
</div>

<div id="odeme-popup" style="display: none; position: fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.6); z-index:9999; justify-content:center; align-items:center;">
  <div style="background:white; padding:40px; border-radius:10px; text-align:center; max-width:400px; width:90%;">
    <h2>Ödeme Başarılı!</h2>
    <p>Alışverişiniz için teşekkür ederiz. 🎉</p>
    <button id="popup-kapat" style="margin-top:20px; padding:10px 20px; background:#4CAF50; color:white; border:none; border-radius:5px;">Kapat</button>
  </div>
</div>

<?php include("partials/footer.php"); ?>
<script src="sepet.js"></script>
</body>
</html>
