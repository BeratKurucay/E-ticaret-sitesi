
document.addEventListener('DOMContentLoaded', function () {
  const sepeteEkleButonlari = document.querySelectorAll('.sepete-ekle');
  const odemeYapButonu = document.getElementById('odeme-yap');
  const musteriPopup = document.getElementById('musteri-popup');
  const kartPopup = document.getElementById('kart-popup');
  const musteriFormu = document.getElementById('musteri-formu');
  const kartFormu = document.getElementById('kart-formu');
  const musteriKapat = document.getElementById('musteri-kapat');
  const kartKapat = document.getElementById('kart-kapat');
  const sepetListesi = document.getElementById('sepet-listesi');
  const popupKapat = document.getElementById('popup-kapat');
  const odemePopup = document.getElementById('odeme-popup');

  let sepet = JSON.parse(localStorage.getItem('sepet')) || [];

  function showToast(msg, duration = 3000) {
    const toast = document.createElement('div');
    toast.textContent = msg;
    toast.style.position = 'fixed';
    toast.style.bottom = '30px';
    toast.style.right = '30px';
    toast.style.backgroundColor = '#323232';
    toast.style.color = '#fff';
    toast.style.padding = '10px 20px';
    toast.style.borderRadius = '6px';
    toast.style.boxShadow = '0 2px 10px rgba(0,0,0,0.2)';
    toast.style.zIndex = 10000;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), duration);
  }

  function sepetiGuncelle() {
    sepetListesi.innerHTML = '';
    if (sepet.length === 0) {
      odemeYapButonu.style.display = 'none';
      sepetListesi.innerHTML = '<li>Sepetiniz boş.</li>';
      return;
    }
    let toplamFiyat = 0;
    sepet.forEach(function (urun, index) {
      toplamFiyat += urun.adet * urun.fiyat;
      const li = document.createElement('li');
      li.innerHTML = `
        <div style="display:flex; align-items:center; gap:10px;">
          <img src="${urun.resim}" style="width:50px; height:50px; object-fit:cover; border-radius:5px;">
          <div>
            <strong>${urun.ad}</strong><br>
            ${urun.fiyat} TL x ${urun.adet} = <strong>${(urun.fiyat * urun.adet).toFixed(2)} TL</strong><br>
            <button title="Azalt" class="azalt" data-index="${index}" style="margin-top:5px;">-</button>
            <button title="Arttır" class="arttir" data-index="${index}" style="margin-top:5px;">+</button>
            <button title="Sil" class="sil" data-index="${index}" style="background:red; color:white; margin-top:5px;">Sil</button>
          </div>
        </div>
      `;
      sepetListesi.appendChild(li);
    });

    const toplamLi = document.createElement('li');
    toplamLi.innerHTML = `
      <div style="margin-top:20px; text-align:center;">
        <strong>Toplam Tutar: ${toplamFiyat.toFixed(2)} TL</strong>
      </div>
    `;
    toplamLi.style.marginTop = '10px';
    toplamLi.style.borderTop = '1px solid #ccc';
    toplamLi.style.paddingTop = '10px';
    sepetListesi.appendChild(toplamLi);

    localStorage.setItem('sepet', JSON.stringify(sepet));
  }

  sepetListesi.addEventListener('click', function (e) {
    const index = e.target.getAttribute('data-index');
    if (!index) return;

    if (e.target.classList.contains('azalt')) {
      sepet[index].adet--;
      if (sepet[index].adet <= 0) sepet.splice(index, 1);
    } else if (e.target.classList.contains('arttir')) {
      sepet[index].adet++;
    } else if (e.target.classList.contains('sil')) {
      sepet.splice(index, 1);
    }
    sepetiGuncelle();
  });

  odemeYapButonu?.addEventListener('click', function () {
    if (sepet.length === 0) {
      alert("Sepetiniz boş!");
    } else {
      musteriPopup.style.display = 'flex';
    }
  });

  musteriFormu?.addEventListener('submit', function (e) {
    e.preventDefault();
    musteriPopup.style.display = 'none';
    kartPopup.style.display = 'flex';
  });

  kartFormu?.addEventListener('submit', function (e) {
    e.preventDefault();
    sepet = [];
    localStorage.removeItem('sepet');
    kartPopup.style.display = 'none';
    odemePopup.style.display = 'flex';
    sepetiGuncelle();
  });

  popupKapat?.addEventListener('click', function () {
    odemePopup.style.display = 'none';
  });

  musteriKapat?.addEventListener('click', function () {
    musteriPopup.style.display = 'none';
  });

  kartKapat?.addEventListener('click', function () {
    kartPopup.style.display = 'none';
  });

  sepeteEkleButonlari.forEach(function (button) {
    button.addEventListener('click', function () {
      const isim = this.getAttribute('data-isim');
      const fiyat = parseFloat(this.getAttribute('data-fiyat'));
      const resim = this.getAttribute('data-resim') || this.closest('.urun-karti')?.querySelector('img')?.src || '';
      const mevcutUrun = sepet.find(urun => urun.ad === isim);

      if (mevcutUrun) {
        mevcutUrun.adet++;
      } else {
        sepet.push({ ad: isim, fiyat: fiyat, adet: 1, resim: resim });
      }

      showToast(`${isim} sepete eklendi.`);
      sepetiGuncelle();
    });
  });

  sepetiGuncelle();
});
